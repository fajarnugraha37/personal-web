import{a as t}from"../chunks/entry.BUEnvv7M.js";export{t as start};
