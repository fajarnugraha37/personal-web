const e="Shakespeare";export{e as t};
