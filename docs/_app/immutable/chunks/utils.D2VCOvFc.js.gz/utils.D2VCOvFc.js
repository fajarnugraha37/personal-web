function m(t,e="medium",a="en"){const r=new Date(t.replaceAll("-","/"));return new Intl.DateTimeFormat(a,{dateStyle:e}).format(r)}export{m as f};
